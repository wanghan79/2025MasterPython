#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
from tqdm import tqdm
from itertools import product
from .base_model import CognitiveModel

class DINA(CognitiveModel):
    """
    DINA (Deterministic Input, Noisy "And" Gate) 模型实现
    
    DINA模型假设学生需要掌握题目所需的所有知识点才能正确回答问题。
    模型基于以下假设:
    1. 知识状态是二进制的（掌握/不掌握）
    2. 所有相关知识点都需要掌握才能解决问题（AND规则）
    3. 猜测和失误引入噪声
    
    参数:
    - slip: 失误参数，掌握所有必要知识点但回答错误的概率
    - guess: 猜测参数，未掌握所有必要知识点但回答正确的概率
    """
    
    def __init__(self, name="DINA"):
        """初始化DINA模型"""
        super().__init__(name=name)
        
        # DINA特定参数
        self.slip = None  # 失误参数，每题一个
        self.guess = None  # 猜测参数，每题一个
        self.latent_classes = None  # 潜在类别模式
        self.class_probabilities = None  # 各潜在类别的概率
        
    def _fit(self, verbose=True):
        """
        使用EM算法训练DINA模型
        
        参数:
        - verbose: 是否显示训练过程
        """
        # 计算所有可能的潜在类别(知识状态)
        self._generate_latent_classes()
        n_classes = len(self.latent_classes)
        
        # 初始化模型参数
        self.slip = np.random.uniform(0.1, 0.3, self.n_questions)  # 初始化失误率在0.1到0.3之间
        self.guess = np.random.uniform(0.1, 0.3, self.n_questions)  # 初始化猜测率在0.1到0.3之间
        self.class_probabilities = np.ones(n_classes) / n_classes  # 均匀初始化类别概率
        
        # 计算每个潜在类别对每个题目的理想反应
        ideal_responses = self._compute_ideal_responses()
        
        # EM算法迭代
        prev_log_likelihood = -np.inf
        converged = False
        
        iterator = range(self.max_iter)
        if verbose:
            iterator = tqdm(iterator, desc="EM迭代")
            
        for iteration in iterator:
            # E步：计算后验概率
            posterior = self._e_step(ideal_responses)
            
            # M步：更新参数
            self._m_step(posterior, ideal_responses)
            
            # 计算对数似然
            log_likelihood = self._compute_log_likelihood(ideal_responses)
            
            if verbose and iteration % 10 == 0:
                self.logger.info(f"迭代 {iteration}, 对数似然: {log_likelihood:.4f}")
                
            # 检查收敛
            if abs(log_likelihood - prev_log_likelihood) < self.tol:
                converged = True
                break
                
            prev_log_likelihood = log_likelihood
            
        if verbose:
            if converged:
                self.logger.info(f"EM算法在第 {iteration+1} 次迭代后收敛")
            else:
                self.logger.warning(f"EM算法在达到最大迭代次数 {self.max_iter} 后未收敛")
                
            self.logger.info(f"最终对数似然: {log_likelihood:.4f}")
            
        # 计算每个学生掌握每个知识点的概率
        self._compute_skill_mastery(posterior)
        
    def _generate_latent_classes(self):
        """生成所有可能的潜在类别（知识状态模式）"""
        # 对于k个知识点，有2^k个可能的知识状态
        # 每个状态表示为一个长度为k的0/1向量
        self.latent_classes = np.array(list(product([0, 1], repeat=self.n_skills)))
    
    def _compute_ideal_responses(self):
        """
        计算每个潜在类别对每个题目的理想反应
        
        返回:
        - ideal_responses: 形状为 (n_classes, n_questions) 的数组
        """
        n_classes = len(self.latent_classes)
        ideal_responses = np.zeros((n_classes, self.n_questions))
        
        for c in range(n_classes):
            alpha_c = self.latent_classes[c]  # 当前类别的知识状态
            
            for j in range(self.n_questions):
                q_j = self.q_matrix[j]  # 题目j的Q向量
                
                # 计算潜在知识变量η（eta）
                # 学生掌握了题目j所需的所有知识点，则eta=1，否则eta=0
                required_skills = np.where(q_j == 1)[0]
                if len(required_skills) == 0:
                    eta = 1  # 如果题目不需要任何知识点
                else:
                    eta = np.prod(alpha_c[required_skills])
                    
                ideal_responses[c, j] = eta
                
        return ideal_responses
        
    def _e_step(self, ideal_responses):
        """
        E步：计算每个学生属于每个潜在类别的后验概率
        
        参数:
        - ideal_responses: 形状为 (n_classes, n_questions) 的理想反应数组
        
        返回:
        - posterior: 形状为 (n_students, n_classes) 的后验概率数组
        """
        n_classes = len(self.latent_classes)
        posterior = np.zeros((self.n_students, n_classes))
        
        for i in range(self.n_students):
            for c in range(n_classes):
                # 计算学生i在假设属于类别c时的似然
                likelihood = 1.0
                
                for j in range(self.n_questions):
                    eta = ideal_responses[c, j]
                    y_ij = self.response_data[i, j]
                    
                    if eta == 1:  # 学生掌握了所有必要知识点
                        p_correct = 1 - self.slip[j]  # 正确回答的概率 = 1 - 失误率
                    else:  # 学生未掌握所有必要知识点
                        p_correct = self.guess[j]  # 正确回答的概率 = 猜测率
                        
                    # 计算观察到的反应的概率
                    p_response = p_correct if y_ij == 1 else (1 - p_correct)
                    likelihood *= p_response
                    
                # 计算后验概率
                posterior[i, c] = likelihood * self.class_probabilities[c]
                
            # 归一化每个学生的后验概率
            if np.sum(posterior[i]) > 0:
                posterior[i] /= np.sum(posterior[i])
                
        return posterior
        
    def _m_step(self, posterior, ideal_responses):
        """
        M步：更新模型参数
        
        参数:
        - posterior: 形状为 (n_students, n_classes) 的后验概率数组
        - ideal_responses: 形状为 (n_classes, n_questions) 的理想反应数组
        """
        n_classes = len(self.latent_classes)
        
        # 更新类别概率
        self.class_probabilities = np.mean(posterior, axis=0)
        
        # 更新猜测和失误参数
        for j in range(self.n_questions):
            # 猜测参数: P(Y=1|eta=0)
            numerator = 0
            denominator = 0
            
            for i in range(self.n_students):
                for c in range(n_classes):
                    if ideal_responses[c, j] == 0:  # 学生未掌握必要知识点
                        numerator += posterior[i, c] * self.response_data[i, j]
                        denominator += posterior[i, c]
                        
            if denominator > 0:
                self.guess[j] = numerator / denominator
            else:
                self.guess[j] = 0.2  # 默认值
                
            # 限制猜测参数在合理范围内
            self.guess[j] = np.clip(self.guess[j], 0.01, 0.5)
                
            # 失误参数: P(Y=0|eta=1)
            numerator = 0
            denominator = 0
            
            for i in range(self.n_students):
                for c in range(n_classes):
                    if ideal_responses[c, j] == 1:  # 学生掌握了必要知识点
                        numerator += posterior[i, c] * (1 - self.response_data[i, j])
                        denominator += posterior[i, c]
                        
            if denominator > 0:
                self.slip[j] = numerator / denominator
            else:
                self.slip[j] = 0.2  # 默认值
                
            # 限制失误参数在合理范围内
            self.slip[j] = np.clip(self.slip[j], 0.01, 0.5)
            
    def _compute_log_likelihood(self, ideal_responses):
        """
        计算对数似然
        
        参数:
        - ideal_responses: 形状为 (n_classes, n_questions) 的理想反应数组
        
        返回:
        - log_likelihood: 对数似然值
        """
        n_classes = len(self.latent_classes)
        log_likelihood = 0
        
        for i in range(self.n_students):
            student_likelihood = 0
            
            for c in range(n_classes):
                class_likelihood = self.class_probabilities[c]
                
                for j in range(self.n_questions):
                    eta = ideal_responses[c, j]
                    y_ij = self.response_data[i, j]
                    
                    if eta == 1:  # 学生掌握了所有必要知识点
                        p_correct = 1 - self.slip[j]
                    else:  # 学生未掌握所有必要知识点
                        p_correct = self.guess[j]
                        
                    p_response = p_correct if y_ij == 1 else (1 - p_correct)
                    class_likelihood *= p_response
                    
                student_likelihood += class_likelihood
                
            if student_likelihood > 0:
                log_likelihood += np.log(student_likelihood)
                
        return log_likelihood
        
    def _compute_skill_mastery(self, posterior):
        """
        计算学生掌握各知识点的概率
        
        参数:
        - posterior: 形状为 (n_students, n_classes) 的后验概率数组
        """
        self.skill_mastery = np.zeros((self.n_students, self.n_skills))
        
        for i in range(self.n_students):
            for k in range(self.n_skills):
                # 对于每个学生和知识点，计算学生掌握该知识点的概率
                # 通过对所有包含该知识点的类别的后验概率求和
                mask = self.latent_classes[:, k] == 1
                self.skill_mastery[i, k] = np.sum(posterior[i, mask])
                
    def _predict(self, q_matrix):
        """
        预测学生反应
        
        参数:
        - q_matrix: 题目的Q矩阵，形状为 (n_questions, n_skills)
        
        返回:
        - predictions: 预测的反应，形状为 (n_students, n_questions)
        """
        n_questions = q_matrix.shape[0]
        predictions = np.zeros((self.n_students, n_questions))
        
        # 计算每个题目的理想反应
        for i in range(self.n_students):
            for j in range(n_questions):
                # 判断学生是否掌握题目所需的所有知识点
                required_skills = np.where(q_matrix[j] == 1)[0]
                
                if len(required_skills) == 0:
                    eta = 1  # 如果题目不需要任何知识点
                else:
                    skill_probs = self.skill_mastery[i, required_skills]
                    # 假设学生掌握所有必要知识点的概率
                    eta_prob = np.prod(skill_probs)
                    # 二值化处理
                    eta = 1 if np.random.random() < eta_prob else 0
                    
                # 根据失误率和猜测率计算正确回答的概率
                if j < len(self.slip) and j < len(self.guess):  # 确保索引在范围内
                    slip = self.slip[j]
                    guess = self.guess[j]
                else:
                    # 如果是新题目，使用平均失误率和猜测率
                    slip = np.mean(self.slip)
                    guess = np.mean(self.guess)
                    
                if eta == 1:
                    p_correct = 1 - slip
                else:
                    p_correct = guess
                    
                # 根据概率预测反应
                predictions[i, j] = 1 if np.random.random() < p_correct else 0
                
        return predictions
        
    def _get_model_params(self):
        """获取模型特定参数"""
        return {
            'slip': self.slip.tolist() if self.slip is not None else None,
            'guess': self.guess.tolist() if self.guess is not None else None,
            'class_probabilities': self.class_probabilities.tolist() if self.class_probabilities is not None else None,
            'latent_classes': self.latent_classes.tolist() if self.latent_classes is not None else None
        }
        
    def _set_model_params(self, params):
        """设置模型特定参数"""
        self.slip = np.array(params['slip']) if params['slip'] is not None else None
        self.guess = np.array(params['guess']) if params['guess'] is not None else None
        self.class_probabilities = np.array(params['class_probabilities']) if params['class_probabilities'] is not None else None
        self.latent_classes = np.array(params['latent_classes']) if params['latent_classes'] is not None else None 