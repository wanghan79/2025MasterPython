#!/usr/bin/env python
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from abc import ABC, abstractmethod
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import time
import logging
import os
from tqdm import tqdm

class CognitiveModel(ABC):
    """
    认知诊断模型基类
    定义了所有认知诊断模型需要实现的接口
    """
    
    def __init__(self, name="BaseModel"):
        """
        初始化认知诊断模型
        
        参数:
        - name: 模型名称
        """
        self.name = name
        self.is_fitted = False
        self.logger = self._setup_logger()
        
        # 模型参数
        self.n_students = None  # 学生数量
        self.n_questions = None  # 题目数量
        self.n_skills = None  # 知识点数量
        self.q_matrix = None  # Q矩阵，表示每道题目对应的知识点
        self.skill_mastery = None  # 学生掌握知识点的概率矩阵
        
        # 学习参数
        self.max_iter = 100  # 最大迭代次数
        self.tol = 1e-6  # 收敛阈值
        self.random_state = 42  # 随机数种子
        
    def _setup_logger(self):
        """配置日志记录器"""
        logger = logging.getLogger(f"CDM.{self.name}")
        if not logger.handlers:
            logger.setLevel(logging.INFO)
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)
        return logger
    
    def fit(self, response_data, q_matrix, max_iter=100, tol=1e-6, random_state=42, verbose=True):
        """
        训练认知诊断模型
        
        参数:
        - response_data: 学生对题目的反应数据，形状为 (n_students, n_questions)
        - q_matrix: Q矩阵，形状为 (n_questions, n_skills)
        - max_iter: 最大迭代次数
        - tol: 收敛阈值
        - random_state: 随机数种子
        - verbose: 是否显示训练过程
        
        返回:
        - self: 返回模型实例
        """
        start_time = time.time()
        
        # 设置参数
        self.max_iter = max_iter
        self.tol = tol
        self.random_state = random_state
        
        # 初始化数据维度
        self.response_data = np.array(response_data)
        self.q_matrix = np.array(q_matrix)
        self.n_students, self.n_questions = self.response_data.shape
        _, self.n_skills = self.q_matrix.shape
        
        np.random.seed(self.random_state)
        
        if verbose:
            self.logger.info(f"开始训练 {self.name} 模型")
            self.logger.info(f"数据维度: 学生数量={self.n_students}, 题目数量={self.n_questions}, 知识点数量={self.n_skills}")
        
        # 调用具体模型的训练方法
        self._fit(verbose)
        
        self.is_fitted = True
        
        if verbose:
            elapsed = time.time() - start_time
            self.logger.info(f"{self.name} 模型训练完成，耗时: {elapsed:.2f} 秒")
            
        return self
    
    @abstractmethod
    def _fit(self, verbose=True):
        """具体模型的训练实现，由子类重写"""
        pass
    
    def predict(self, q_matrix=None):
        """
        预测学生的反应
        
        参数:
        - q_matrix: 测试题目的Q矩阵，如果不提供则使用训练时的Q矩阵
        
        返回:
        - predictions: 预测的学生反应
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用 fit() 方法")
            
        if q_matrix is None:
            q_matrix = self.q_matrix
        else:
            q_matrix = np.array(q_matrix)
            
        return self._predict(q_matrix)
    
    @abstractmethod
    def _predict(self, q_matrix):
        """具体模型的预测实现，由子类重写"""
        pass
    
    def evaluate(self, true_responses, pred_responses=None, metrics=None):
        """
        评估模型性能
        
        参数:
        - true_responses: 真实反应数据
        - pred_responses: 预测的反应数据，如不提供则自动调用predict方法
        - metrics: 评估指标列表，默认为['accuracy', 'precision', 'recall', 'f1']
        
        返回:
        - results: 包含各评估指标的字典
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用 fit() 方法")
            
        if metrics is None:
            metrics = ['accuracy', 'precision', 'recall', 'f1']
            
        true_responses = np.array(true_responses).flatten()
        
        if pred_responses is None:
            pred_responses = self.predict().flatten()
        else:
            pred_responses = np.array(pred_responses).flatten()
            
        results = {}
        
        if 'accuracy' in metrics:
            results['accuracy'] = accuracy_score(true_responses, pred_responses)
            
        if 'precision' in metrics:
            results['precision'] = precision_score(true_responses, pred_responses, zero_division=0)
            
        if 'recall' in metrics:
            results['recall'] = recall_score(true_responses, pred_responses, zero_division=0)
            
        if 'f1' in metrics:
            results['f1'] = f1_score(true_responses, pred_responses, zero_division=0)
            
        return results
    
    def get_skill_mastery(self):
        """
        获取学生对知识点的掌握概率
        
        返回:
        - skill_mastery: 学生掌握知识点的概率矩阵，形状为 (n_students, n_skills)
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用 fit() 方法")
        return self.skill_mastery
    
    def save_model(self, filepath):
        """
        保存模型参数到文件
        
        参数:
        - filepath: 保存文件路径
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用 fit() 方法")
            
        model_params = {
            'name': self.name,
            'n_students': self.n_students,
            'n_questions': self.n_questions,
            'n_skills': self.n_skills,
            'q_matrix': self.q_matrix.tolist() if self.q_matrix is not None else None,
            'skill_mastery': self.skill_mastery.tolist() if self.skill_mastery is not None else None,
            'model_specific_params': self._get_model_params()
        }
        
        import json
        with open(filepath, 'w') as f:
            json.dump(model_params, f)
            
        self.logger.info(f"模型已保存到 {filepath}")
    
    def load_model(self, filepath):
        """
        从文件加载模型参数
        
        参数:
        - filepath: 模型文件路径
        
        返回:
        - self: 返回模型实例
        """
        import json
        with open(filepath, 'r') as f:
            model_params = json.load(f)
            
        self.name = model_params['name']
        self.n_students = model_params['n_students']
        self.n_questions = model_params['n_questions']
        self.n_skills = model_params['n_skills']
        self.q_matrix = np.array(model_params['q_matrix']) if model_params['q_matrix'] is not None else None
        self.skill_mastery = np.array(model_params['skill_mastery']) if model_params['skill_mastery'] is not None else None
        self._set_model_params(model_params['model_specific_params'])
        
        self.is_fitted = True
        self.logger.info(f"模型已从 {filepath} 加载")
        
        return self
    
    @abstractmethod
    def _get_model_params(self):
        """获取模型特定参数，由子类重写"""
        return {}
    
    @abstractmethod
    def _set_model_params(self, params):
        """设置模型特定参数，由子类重写"""
        pass
    
    def plot_skill_mastery(self, skill_names=None, student_ids=None, figsize=(10, 6), save_path=None):
        """
        可视化学生的知识点掌握情况
        
        参数:
        - skill_names: 知识点名称列表
        - student_ids: 要展示的学生ID列表，如不提供则展示所有学生的平均水平
        - figsize: 图形尺寸
        - save_path: 图片保存路径，如不提供则显示图形
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用 fit() 方法")
            
        if skill_names is None:
            skill_names = [f"知识点 {i+1}" for i in range(self.n_skills)]
            
        if len(skill_names) != self.n_skills:
            raise ValueError(f"知识点名称数量 ({len(skill_names)}) 与知识点数量 ({self.n_skills}) 不匹配")
            
        plt.figure(figsize=figsize)
        
        if student_ids is None:
            # 显示所有学生的平均掌握程度
            avg_mastery = np.mean(self.skill_mastery, axis=0)
            plt.bar(skill_names, avg_mastery)
            plt.title("所有学生的平均知识点掌握程度")
        else:
            # 显示指定学生的掌握程度
            if isinstance(student_ids, int):
                student_ids = [student_ids]
                
            for student_id in student_ids:
                if student_id < 0 or student_id >= self.n_students:
                    raise ValueError(f"学生ID {student_id} 超出范围 [0, {self.n_students-1}]")
                    
            if len(student_ids) > 10:
                self.logger.warning("指定的学生数量过多，图形可能会很拥挤")
                
            x = np.arange(len(skill_names))
            width = 0.8 / len(student_ids)
            
            for i, student_id in enumerate(student_ids):
                plt.bar(x + (i - len(student_ids)/2 + 0.5) * width, 
                       self.skill_mastery[student_id], 
                       width=width,
                       label=f"学生 {student_id}")
                
            plt.title("学生知识点掌握程度对比")
            plt.legend()
            
        plt.xlabel("知识点")
        plt.ylabel("掌握概率")
        plt.ylim(0, 1)
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            self.logger.info(f"图形已保存到 {save_path}")
        else:
            plt.show() 