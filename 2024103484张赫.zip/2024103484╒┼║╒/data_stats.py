import math
import numpy as np
from typing import List, Dict, Any, Callable, Union, Set, Tuple
from functools import wraps

class StatsDecorator:
    """
    带参数的数据统计装饰器类
    
    用于装饰数据生成函数，对生成的数值型数据进行统计分析
    可选统计项：SUM（求和）、AVG（均值）、VAR（方差）、RMSE（均方根误差）
    """
    
    def __init__(self, *stats_ops):
        """
        初始化装饰器
        
        参数:
            *stats_ops: 字符串，指定要计算的统计量，可以是 'SUM'、'AVG'、'VAR'、'RMSE' 中的任意组合
        """
        # 如果没有提供统计操作，默认使用全部
        self.stats_ops = set(stats_ops) if stats_ops else {'SUM', 'AVG', 'VAR', 'RMSE'}
        # 验证输入的统计操作是否有效
        valid_ops = {'SUM', 'AVG', 'VAR', 'RMSE'}
        if not self.stats_ops.issubset(valid_ops):
            invalid_ops = self.stats_ops - valid_ops
            raise ValueError(f"无效的统计操作: {invalid_ops}。有效操作包括: {valid_ops}")
    
    def __call__(self, func):
        """
        装饰器核心方法，用于包装被装饰的函数
        
        参数:
            func: 要装饰的函数
            
        返回:
            包装后的函数
        """
        @wraps(func)
        def wrapper(*args, **kwargs):
            # 调用原始函数获取生成的数据
            data = func(*args, **kwargs)
            
            # 添加analyze方法到返回的数据中
            if isinstance(data, list):
                # 为了不修改原始数据，创建一个新的对象
                enhanced_data = list(data)
                setattr(enhanced_data, 'analyze', lambda: self.analyze(data))
                return enhanced_data
            else:
                # 如果不是列表，将其包装在列表中
                data_list = [data]
                enhanced_data = list(data_list)
                setattr(enhanced_data, 'analyze', lambda: self.analyze(data_list))
                return enhanced_data
        
        return wrapper
    
    def analyze(self, data: List[Any]) -> Dict[str, Dict[str, float]]:
        """
        分析数据中的数值型叶节点并计算统计指标
        
        参数:
            data: 要分析的数据列表
            
        返回:
            包含统计结果的字典
        """
        # 提取所有数值型数据
        numeric_values = self._extract_numeric_values(data)
        
        # 计算指定的统计量
        results = {}
        for field, values in numeric_values.items():
            results[field] = {}
            
            # 对每个字段计算指定的统计量
            if 'SUM' in self.stats_ops:
                results[field]['SUM'] = sum(values)
                
            if 'AVG' in self.stats_ops:
                results[field]['AVG'] = sum(values) / len(values) if values else 0
                
            if 'VAR' in self.stats_ops:
                if len(values) > 1:
                    mean = sum(values) / len(values)
                    variance = sum((x - mean) ** 2 for x in values) / len(values)
                    results[field]['VAR'] = variance
                else:
                    results[field]['VAR'] = 0
                    
            if 'RMSE' in self.stats_ops:
                if values:
                    # RMSE通常是预测值与真实值之间的差异，这里计算与均值的RMSE
                    mean = sum(values) / len(values)
                    rmse = math.sqrt(sum((x - mean) ** 2 for x in values) / len(values))
                    results[field]['RMSE'] = rmse
                else:
                    results[field]['RMSE'] = 0
        
        return results
    
    def _extract_numeric_values(self, data: List[Any]) -> Dict[str, List[Union[int, float]]]:
        """
        从嵌套数据结构中提取所有数值型叶节点
        
        参数:
            data: 要处理的数据列表
            
        返回:
            包含字段路径和对应数值列表的字典
        """
        result = {}
        
        def traverse(obj, path=""):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    new_path = f"{path}.{key}" if path else key
                    traverse(value, new_path)
            elif isinstance(obj, (list, tuple)):
                for i, item in enumerate(obj):
                    new_path = f"{path}[{i}]"
                    traverse(item, new_path)
            elif isinstance(obj, (int, float)) and not isinstance(obj, bool):
                if path not in result:
                    result[path] = []
                result[path].append(obj)
        
        for item in data:
            traverse(item)
            
        return result


# 简化使用的装饰器函数
def stats_decorator(*args):
    """
    数据统计装饰器
    
    参数:
        *args: 字符串，指定要计算的统计量，可以是 'SUM'、'AVG'、'VAR'、'RMSE' 中的任意组合
        
    返回:
        StatsDecorator装饰器实例
    """
    return StatsDecorator(*args) 