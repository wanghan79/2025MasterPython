import random
import string
import datetime
from typing import Dict, List, Any, Tuple, Union, Optional

class DataSampler:
    """随机数据生成器，用于生成结构化的模拟数据"""
    
    @staticmethod
    def generate_int(min_val: int = 0, max_val: int = 100) -> int:
        """生成随机整数"""
        return random.randint(min_val, max_val)
    
    @staticmethod
    def generate_float(min_val: float = 0.0, max_val: float = 1.0, precision: int = 2) -> float:
        """生成随机浮点数"""
        val = random.uniform(min_val, max_val)
        return round(val, precision)
    
    @staticmethod
    def generate_str(length: int = 10) -> str:
        """生成随机字符串"""
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))
    
    @staticmethod
    def generate_bool() -> bool:
        """生成随机布尔值"""
        return random.choice([True, False])
    
    @staticmethod
    def generate_date(start_date: datetime.date = datetime.date(2000, 1, 1),
                     end_date: datetime.date = datetime.date.today()) -> datetime.date:
        """生成随机日期"""
        time_delta = (end_date - start_date).days
        random_days = random.randint(0, time_delta)
        return start_date + datetime.timedelta(days=random_days)
    
    @classmethod
    def generate_list(cls, item_type: Dict[str, Any], length: int = 5) -> List[Any]:
        """生成随机列表"""
        return [cls.generate_value(item_type) for _ in range(length)]
    
    @classmethod
    def generate_tuple(cls, item_types: List[Dict[str, Any]]) -> Tuple[Any, ...]:
        """生成随机元组"""
        return tuple(cls.generate_value(item_type) for item_type in item_types)
    
    @classmethod
    def generate_dict(cls, schema: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """生成随机字典"""
        return {key: cls.generate_value(value) for key, value in schema.items()}
    
    @classmethod
    def generate_value(cls, type_spec: Dict[str, Any]) -> Any:
        """根据类型规范生成随机值"""
        data_type = type_spec.get('type', 'str')
        
        if data_type == 'int':
            min_val = type_spec.get('min', 0)
            max_val = type_spec.get('max', 100)
            return cls.generate_int(min_val, max_val)
        
        elif data_type == 'float':
            min_val = type_spec.get('min', 0.0)
            max_val = type_spec.get('max', 1.0)
            precision = type_spec.get('precision', 2)
            return cls.generate_float(min_val, max_val, precision)
        
        elif data_type == 'str':
            length = type_spec.get('length', 10)
            return cls.generate_str(length)
        
        elif data_type == 'bool':
            return cls.generate_bool()
        
        elif data_type == 'date':
            start_date_str = type_spec.get('start_date', '2000-01-01')
            end_date_str = type_spec.get('end_date', datetime.date.today().isoformat())
            
            if isinstance(start_date_str, str):
                start_date = datetime.date.fromisoformat(start_date_str)
            else:
                start_date = start_date_str
                
            if isinstance(end_date_str, str):
                end_date = datetime.date.fromisoformat(end_date_str)
            else:
                end_date = end_date_str
                
            return cls.generate_date(start_date, end_date)
        
        elif data_type == 'list':
            item_type = type_spec.get('item_type', {'type': 'str'})
            length = type_spec.get('length', 5)
            return cls.generate_list(item_type, length)
        
        elif data_type == 'tuple':
            item_types = type_spec.get('item_types', [{'type': 'str'}, {'type': 'int'}])
            return cls.generate_tuple(item_types)
        
        elif data_type == 'dict':
            schema = type_spec.get('schema', {'key': {'type': 'str'}})
            return cls.generate_dict(schema)
        
        else:
            return None
    
    @classmethod
    def generate_samples(cls, schema: Dict[str, Dict[str, Any]], count: int = 1) -> List[Any]:
        """生成指定数量的样本"""
        return [cls.generate_value(schema) for _ in range(count)]


def generate_data(**kwargs):
    """
    生成结构化的随机数据样本
    
    参数:
        **kwargs: 
            - schema: 定义数据结构的字典
            - count: 要生成的样本数量（默认为1）
    
    返回:
        生成的随机数据样本
    """
    schema = kwargs.get('schema', {'type': 'dict', 'schema': {'name': {'type': 'str'}}})
    count = kwargs.get('count', 1)
    
    return DataSampler.generate_samples(schema, count)


# 示例用法
if __name__ == "__main__":
    # 示例1：生成用户数据
    user_schema = {
        'type': 'dict',
        'schema': {
            'user_id': {'type': 'int', 'min': 10000, 'max': 99999},
            'username': {'type': 'str', 'length': 8},
            'is_active': {'type': 'bool'},
            'join_date': {'type': 'date', 'start_date': '2020-01-01'},
            'profile': {
                'type': 'dict',
                'schema': {
                    'age': {'type': 'int', 'min': 18, 'max': 80},
                    'email': {'type': 'str', 'length': 12},
                    'preferences': {
                        'type': 'list',
                        'item_type': {'type': 'str', 'length': 5},
                        'length': 3
                    }
                }
            },
            'scores': {'type': 'list', 'item_type': {'type': 'float', 'min': 0, 'max': 100}, 'length': 5}
        }
    }
    
    users = generate_data(schema=user_schema, count=3)
    print("用户数据示例:")
    for user in users:
        print(user)
    print()
    
    # 示例2：生成产品数据
    product_schema = {
        'type': 'dict',
        'schema': {
            'product_id': {'type': 'str', 'length': 6},
            'name': {'type': 'str', 'length': 10},
            'price': {'type': 'float', 'min': 10.0, 'max': 1000.0, 'precision': 2},
            'in_stock': {'type': 'bool'},
            'categories': {'type': 'tuple', 'item_types': [
                {'type': 'str', 'length': 5}, 
                {'type': 'str', 'length': 8}
            ]},
            'reviews': {
                'type': 'list',
                'item_type': {
                    'type': 'dict',
                    'schema': {
                        'rating': {'type': 'int', 'min': 1, 'max': 5},
                        'comment': {'type': 'str', 'length': 20},
                        'date': {'type': 'date', 'start_date': '2022-01-01'}
                    }
                },
                'length': 2
            }
        }
    }
    
    products = generate_data(schema=product_schema, count=2)
    print("产品数据示例:")
    for product in products:
        print(product) 