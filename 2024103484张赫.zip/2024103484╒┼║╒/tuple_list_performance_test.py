import time
import numpy as np
import random

# 定义矩阵大小和测试轮数
size = 1000  # 使用1000×1000而不是10000×10000以避免内存不足
rounds = 10000

print("开始创建数据结构...")

# 创建list矩阵和tuple矩阵
list_matrix = [[i + j for j in range(size)] for i in range(size)]
# 将list的每行转换为tuple，然后将这些行组成一个tuple
tuple_matrix = tuple(tuple(row) for row in list_matrix)

print("数据结构创建完成，开始测试...")

# 测试list修改性能
print("开始测试list修改性能...")
list_start_time = time.time()
for _ in range(rounds):
    # 随机选择一个位置进行修改
    i = random.randint(0, size-1)
    j = random.randint(0, size-1)
    list_matrix[i][j] = random.randint(0, 100)
list_end_time = time.time()
list_time = list_end_time - list_start_time

print(f"List修改{rounds}次耗时: {list_time:.6f}秒")

# 测试tuple修改性能
print("开始测试tuple修改性能...")
tuple_start_time = time.time()
for _ in range(rounds):
    # 随机选择一个位置进行修改
    i = random.randint(0, size-1)
    j = random.randint(0, size-1)
    # 对于tuple，需要创建一个新的tuple来"修改"元素
    row = list(tuple_matrix[i])
    row[j] = random.randint(0, 100)
    new_row = tuple(row)
    # 然后用新行替换旧行，同样需要重建整个tuple
    tuple_rows = list(tuple_matrix)
    tuple_rows[i] = new_row
    tuple_matrix = tuple(tuple_rows)
tuple_end_time = time.time()
tuple_time = tuple_end_time - tuple_start_time

print(f"Tuple修改{rounds}次耗时: {tuple_time:.6f}秒")

# 比较结果
print("\n性能对比结果:")
print(f"List修改性能: {list_time:.6f}秒")
print(f"Tuple修改性能: {tuple_time:.6f}秒")
print(f"Tuple/List时间比: {tuple_time/list_time:.2f}倍")
print("\n结论:")
print("1. List是可变的，可以直接修改元素，性能较好")
print("2. Tuple是不可变的，每次'修改'都需要创建新的tuple，性能较差")
print("3. 对于需要频繁修改的数据，应优先使用list等可变数据结构") 